
public class CannotActException extends Exception {
	
}
