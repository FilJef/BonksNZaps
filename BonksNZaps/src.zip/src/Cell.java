import java.util.ArrayList;

public class Cell {
	private ArrayList<Being> population;
	
	public Cell(){
		population = new ArrayList<Being>();
	}
	public void add(Being temp){
		population.add(temp);
	}
	
	public void remove(Being temp){
		population.remove(temp);
	}
	
	public void setList(ArrayList<Being> pop){
		population = pop;
	}
	
	public ArrayList<Being> getList(){
		ArrayList<Being> encapsulate = new ArrayList<Being>();
		encapsulate.addAll(population);
		return encapsulate;
	}
}
