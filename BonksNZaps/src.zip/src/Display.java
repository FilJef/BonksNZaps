import java.util.ArrayList;

public class Display {
	int worldSize;
	private Cell worldCopy[][];
	
	
	public Display(int size){
		worldSize = size;
		worldCopy = new Cell[size][size];
	}
	
	/**
	 * adds the worldGrid into the array to be drawn
	 * @param temp
	 */
	public void displayGrid(Cell temp[][]){
		for(int x = 0; x < worldSize; x++){
			for(int y = 0; y< worldSize; y++){
				worldCopy[x][y] = temp[x][y];
			}
		}
		display();
	}
	
	/**
	 * gives the display in rows an columns rather than 400 lines of output each cycle.
	 * also is much nicer to look at and gives a visual representation
	 */
	public void display(){
		//gives a fancy display
		System.out.println("");
		recursiveDraw(0);
		borderLine();
	}
	
	/**
	 * x being the current row i am drawing into the grid, uses recursion to write out the display
	 * @param x
	 */
	public void recursiveDraw(int x){
		Cell temp[] = new Cell[worldSize];
		borderLine();
		//copys a line of the world into an array
		for(int y = 0; y < worldSize; y++){
				temp[y] = worldCopy[x][y];
		}
		//finds the array list with the longest length so we know the height of these cells
		int height = 2;
        for(int y = 0; y < worldSize; y++){
			ArrayList<Being> getSize = worldCopy[x][y].getList();
			if(height < getSize.size()){
				height = getSize.size();
			}
		}
		String output[] = new String[height];
		for(int i = 0; i < height; i++){
			String lineOut = "#";
			for(int o = 0; o < worldSize; o++){
				ArrayList<Being> hold = temp[o].getList();
				try{
					lineOut += makeLength(hold.get(i).getName());
				}
				catch(Exception e){
					lineOut += "      #";
				}
				output[i] += lineOut;
			}
			System.out.println(lineOut);
		}
		if(x < (worldSize - 1)){
			recursiveDraw(x + 1);
		}
	}
	
	/**
	 * temp is a string of <6 length that this will make a length of 6 + #
	 * using this i can support up to 9999 bonks. more if i used hexadecimal (which im obviously not).
	 * @param temp
	 * @return
	 */
	public String makeLength(String temp){
		String output;
		output = temp;
		if( output.length() == 6){
			output += "#";
			return output;
		}
		else{
			do{
				output += " ";
			}while(output.length() != 6);
			output += "#";
		}
		return output;
	}
	
	/**
	 * borderline prints out a horizontal line of #'s of dynamic length 
	 */
	public void borderLine(){
		String ret = "#";
		for(int i = 0; i < worldSize; i++){
			ret += "#######";
		}
		System.out.println(ret);		
	}
}
