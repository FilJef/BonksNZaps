import java.time.Instant;
import java.util.ArrayList;

public class ThreadBoard extends Board{
	int startZap;
	String name;
	int startBonk;
	int days;
	long time;
	public ThreadBoard(int genBonks, int genZaps, int size, boolean player, String title) throws CannotActException {
		super(genBonks, genZaps, size, player);
		name = title;
		startZap = genZaps;
		startBonk = genBonks;
	}
	
	public void run(int cycles) throws CannotActException, InterruptedException{
		long start = System.currentTimeMillis();
		days = cycles;
		for(int i = 0;i < cycles; i++){
			//System.out.println("Day " +(i+1)+ " of day " +cycles);
			setActStatus();
			for(int x = 0; x < worldSize; x++){
				for(int y = 0; y < worldSize; y++){
					ArrayList<Being> temp = world[x][y].getList(); //gets the arraylist of that cell
					ArrayList<Being> toDelete = new ArrayList<Being>(); //beings to delete
					ArrayList<Being> born = new ArrayList<Being>(); //born lol
					for(int b =0; b < temp.size(); b++){
						Being B = temp.get(b);
						temp.remove(B);
						
						if(B instanceof Bonk && ((Bonk) B).getAct()){
							if(((Bonk) B).getAct()){
								B.act();
							}
							
							if(temp.size() > 1){
									born.addAll(((Bonk) B).breed(temp, numOfBonks));
									temp.removeAll(born);
							}
						}
						else if(B instanceof Zap){
							if(((Zap) B).getAct()){
								B.act();
							}
							temp = ((Zap) B).kill(temp);
						}
						Position tempLoc = B.getLocation();
						if(tempLoc.getX() == x && tempLoc.getY() == y){ //checks the move is legal
							temp.add(B);
						}
						else{
							world[tempLoc.getX()][tempLoc.getY()].add(B);
							toDelete.add(B);
						}
					}
					for(Being B: toDelete){
						temp.remove(B);
					}
					numOfBonks += (born.size());
					temp.addAll(born);
					world[x][y].setList(temp);
				}
			}
		}
		long stop = System.currentTimeMillis();
		stop = stop - start;
		time = (stop);
	}
	
	public void getInfo(){
		String info = "";
		info ="[" + name + "] \n";
		info += "Size: "+worldSize + "\n";
		info += "Cycles: " + days + "\n";
		info += "Start Bonks: "+startBonk+ "\n";
		info += "Amount of Zaps: "+startZap+ "\n";
		Position temp = bonksBorn();
		info += "Bonks born: " + temp.getX()+ "\n";
		info += "Bonks killed: " + temp.getY()+ "\n";
		info += "Time in milliseconds: " + time + "\n";
		System.out.println(info);
	}
	
	private Position bonksBorn(){
		int born = 0;
		int died = 0;
		for(int x = 0; x < worldSize; x++){
			for(int y = 0; y < worldSize; y++){
				ArrayList<Being> temp = world[x][y].getList();
				for(Being B:temp){
					if(B instanceof Bonk){
						if(((Bonk)B).getID() > startBonk){
							born +=1;
						}
						if(!((Bonk) B).isAlive()){
							died +=1;
						}
					}
				}
			}
		}
		Position pack = new Position(born,died);
		return pack;
	}
}
