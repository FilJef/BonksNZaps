import java.util.ArrayList;
import java.util.Random;

public class Bonk implements Being {
	String name;
	boolean canBreed;
	boolean alive;
	boolean gender;
	Position location = new Position(0, 0);
	Random rand = new Random();
	int id;
	int worldSize;
	boolean act = true;
	String parent1, parent2;

	public Bonk(int number, Position loc, int size, String name1, String name2) {
		name = "B" + number + "A";
		canBreed = false;
		alive = true;
		location = loc;
		gender = rand.nextBoolean();
		id = number;
		worldSize = size;
		parent1 = name1;
		parent2 = name2;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void act() throws CannotActException {
		move();
		act = false;
	}

	public void kill() {
		alive = false;
		name = "B" + id + "D";
	}

	@Override
	/**
	 * bonks and zaps move in the same way 1,2,3 4,0,5 6,7,8 gets a random
	 * number, checks it can make the move then it does. if it gets 0 it doesnt
	 * move
	 */
	public void move() {
		// location = new Position(location.getY() + (rand.nextInt(3)-1),
		// location.getX()+(rand.nextInt(3)-1));
		if (alive && act) {
			int move = rand.nextInt(9);
			int tempX, tempY;
			switch (move) {
			case 0:
				break;
			case 1:
				tempX = location.getX() - 1;
				tempY = location.getY() - 1;
				location = new Position(tempX, tempY);
				break;
			case 2:
				tempX = location.getX();
				tempY = location.getY() - 1;
				location = new Position(tempX, tempY);
				break;
			case 3:
				tempX = location.getX() + 1;
				tempY = location.getY() - 1;
				location = new Position(tempX, tempY);
				break;
			case 4:
				tempX = location.getX() - 1;
				tempY = location.getY();
				location = new Position(tempX, tempY);
				break;
			case 5:
				tempX = location.getX() + 1;
				tempY = location.getY();
				location = new Position(tempX, tempY);
				break;
			case 6:
				tempX = location.getX() - 1;
				tempY = location.getY() + 1;
				location = new Position(tempX, tempY);
				break;
			case 7:
				tempX = location.getX();
				tempY = location.getY() + 1;
				location = new Position(tempX, tempY);
				break;
			case 8:
				tempX = location.getX() + 1;
				tempY = location.getY() + 1;
				location = new Position(tempX, tempY);
				break;
			}
		}

		if (location.getY() > worldSize - 1) {
			location.setY(worldSize -1);
		} else if (location.getY() < 0) {
			location.setY(0);
		}

		if (location.getX() > worldSize -1) {
			location.setX(worldSize -1);
		} else if (location.getX() < 0) {
			location.setX(0);
		}
	}

	public ArrayList<Being> breed(ArrayList<Being> cellMates, int numOfBonks) {
		ArrayList<Being> add = new ArrayList<Being>();
		if (this.canBreed && alive && cellMates.size() < 10) {
			for (Being B : cellMates) {
				if (B instanceof Bonk) {
					if (((Bonk) B).canBreed() && (((Bonk) B).getGender() != this.gender) && ((Bonk) B).isAlive() && !((Bonk) B).related(this)) {
						numOfBonks += 1;
						Bonk temp = new Bonk(numOfBonks, this.location, worldSize, this.getName(), B.getName());
						add.add(temp);
						((Bonk) B).setBreed(false);
						canBreed = false;
					}
				}
			}
		}
		cellMates.addAll(add);
		return cellMates;
	}
	
	public boolean related(Bonk temp){
		boolean answer = false;
		if((parent1 == temp.getName() || parent2 == temp.getName()) || (this.getName() == temp.parent1 || this.getName() == temp.parent2)){
			answer = true;
		}
		if(parent1 == null){
			answer = false;
		}
		return answer;
	}
	
	public boolean isAlive() {
		return alive;
	}

	public boolean canBreed() {
		return canBreed;
	}

	public void setBreed(boolean set) {
		canBreed = set;
	}

	public boolean getGender() {
		return gender;
	}
	
	public boolean getAct(){
		return act;
	}
	
	public void setAct(boolean input){
		act = input;
	}

	public String toString() {
		String returnable = name;
		return returnable;
	}

	@Override
	public void setLocation(Position temp) {
		location = temp;
	}

	@Override
	public Position getLocation() {
		return location;
	}
	
	public int getID(){
		return id;
	}
}
