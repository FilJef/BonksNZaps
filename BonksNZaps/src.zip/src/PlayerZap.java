import java.util.Scanner;

public class PlayerZap extends Zap {

	public PlayerZap(int number, Position loc, int size) {
		super(number, loc, size);
	}

	public void move() {
		// location = new Position(location.getY() + (rand.nextInt(3)-1),
		// location.getX()+(rand.nextInt(3)-1));
		int move = getInput();
		int tempX, tempY;
		switch (move) {
		case 0:
			break;
		case 1:
			tempX = location.getX() - 1;
			tempY = location.getY() - 1;
			location = new Position(tempX, tempY);
			break;
		case 2:
			tempX = location.getX() - 1;
			tempY = location.getY();
			location = new Position(tempX, tempY);
			break;
		case 3:
			tempX = location.getX() - 1;
			tempY = location.getY() + 1;
			location = new Position(tempX, tempY);
			break;
		case 4:
			tempX = location.getX();
			tempY = location.getY() - 1;
			location = new Position(tempX, tempY);
			break;
		case 5:
			tempX = location.getX();
			tempY = location.getY() + 1;
			location = new Position(tempX, tempY);
			break;
		case 6:
			tempX = location.getX() + 1;
			tempY = location.getY() - 1;
			location = new Position(tempX, tempY);
			break;
		case 7:
			tempX = location.getX() + 1;
			tempY = location.getY();
			location = new Position(tempX, tempY);
			break;
		case 8:
			tempX = location.getX() + 1;
			tempY = location.getY() + 1;
			location = new Position(tempX, tempY);
			break;
		}

		if (location.getY() > worldSize - 1) {
			location.setY(worldSize - 1);
		} else if (location.getY() < 0) {
			location.setY(0);
		}

		if (location.getX() > worldSize - 1) {
			location.setX(worldSize - 1);
		} else if (location.getX() < 0) {
			location.setX(0);
		}
	}

	public int getInput() {
		boolean finish = false;
		int temp = 0;
		System.out.println("1,2,3");
		System.out.println("4,0,5");
		System.out.println("6,7,8");
		System.out
				.println("Where 0 is " + name + "'s current position, if zap moves out of world it is moved back in.");
		Scanner in = new Scanner(System.in);
		do {
			try {
				int hold = in.nextInt();
				temp = hold;
				finish = true;
			} catch (Exception e) {
				System.out.println("Invalid move, please input a number 0 - 8");
				finish = false;
			}
		} while (!finish);
		return temp;
	}
}
