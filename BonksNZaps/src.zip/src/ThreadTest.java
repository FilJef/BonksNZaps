
public class ThreadTest extends Thread{
	
	private ThreadBoard test;
	String name;
	int cyc;
	
	public ThreadTest(String nm){
		name = nm;
	}
	public void run(int b, int z, int s, int c){
		cyc = c;
		try {
			test = new ThreadBoard(b,z,s,false, name);
		} catch (CannotActException e) {
			e.printStackTrace();
		}
	}
	
	public void run(){
		try {
			test.run(cyc);
		} catch (CannotActException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("" + name + " has finished");
	}
	
	public void results(){
		test.getInfo();
	}
	
	public String getNm(){return name;}
}
