/**
 * Bonks and zaps cs12320 major assignment
 * 
 * @author Phillip
 *
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Application {
	private Board gridWorld;
	private Scanner input = new Scanner(System.in);
	private Thread newThread;
	int amountOfBonks = 0, amountOfZaps = 0, cycles = 0, size = 0;
	boolean zaps = false;
	
	public static void main(String[] args) throws CannotActException {
		Application app = new Application();
		app.run();
	}
	
	/**
	 * Shows the menu and gets the users input
	 * @throws CannotActException
	 */
	public void run() throws CannotActException{
		String choice;
		do{
		printMenu();
		choice = getInput();
		switch(choice){
			case "1":
				gridWorld = new Board(20,5,20, false);
			try {
				gridWorld.run(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				break;
			case "2":
				customSim();
				break;
			case "3":
				playerControl();
				break;
			case "4":
				multiThread();
				break;
			case "5":
				System.out.println("Thanks for using this program!");
				break;
			default:
				System.out.println("Not a valid input, please try again");
				break;
		}
		}while(!(choice.equals("5")));
		
	}
	
	/**
	 * Starts a player controlled game
	 * with normal parameters
	 * @throws CannotActException
	 */
	public void playerControl() throws CannotActException{
		gridWorld = new Board(20,5,20, true);
		try {
			gridWorld.run(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Sets up a customised simulation from user boundarys
	 * amount of bonks, zaps, cycles, world size and player controlled zaps
	 * @throws CannotActException
	 */
	private void customSim() throws CannotActException{
		getParams();
		boolean check = true;
		System.out.println("Do you want to control the Zaps (Y/N): ");
		do
			try{
				check = true;
				String loads = getInput();
				char temp = loads.charAt(0);
				if(temp == 'Y'){
					zaps = true;
				}
				else if(temp == 'N'){
					zaps = false;
				}
				else{
					check = false;
				}
			}
			catch(Exception e){
				check = false;
			}
		while(!check);
		gridWorld = new Board(amountOfBonks,amountOfZaps,size, zaps);
		try {
			gridWorld.run(cycles);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * gets the users boundarys for custom/multithreaded simulations except for player controlled zaps
	 */
	public void getParams(){
		boolean check = false;
		System.out.println("How many Bonks will this start with (0 - 200): ");
		do
			try{
				amountOfBonks = Integer.parseInt(getInput());
				if(amountOfBonks < 201 && amountOfBonks > 0){
					check = true;
				}
				else{
					System.out.println("Out of bounds! try again: ");
					check = false;
				}
			}
			catch(Exception e){
				check = false;
			}
		while(!check);
		System.out.println("How many Zaps will be in this world (0 - 150): ");
		do
			try{
				amountOfZaps = Integer.parseInt(getInput());
				if(amountOfZaps < 151 && amountOfZaps > 0){
					check = true;
				}
				else{
					System.out.println("Out of bounds! try again: ");
					check = false;
				}
			}
			catch(Exception e){
				check = false;
			}
		while(!check);
		System.out.println("How many days will be simulated (1 - 10000): ");
		do
			try{
				cycles = Integer.parseInt(getInput());
				check = true;
				if(cycles < 10001 && cycles > 0){
					check = true;
				}
				else{
					System.out.println("Out of bounds! try again: ");
					check = false;
				}
			}
			catch(Exception e){
				check = false;
			}
		while(!check);
		System.out.println("How large is the world (1 - 200): ");
		do
			try{
				size = Integer.parseInt(getInput());
				check = true;
				if(size > 200 || size < 1){
					check = false;
					System.out.println("Out of bounds! try again: ");
				}
			}
			catch(Exception e){
				check = false;
			}
		while(!check);
	}
	
	
	/**
	 * sets up and runs 10 threads, the prints the results of each custom sim. non player controlled.
	 */
	private void multiThread(){
		ArrayList<ThreadTest> threads = new ArrayList<ThreadTest>();
		for(int i = 0; i < 10; i++){
			String temp = "Thread " + (i+ 1);
			newThread= new ThreadTest(temp);
			threads.add((ThreadTest) newThread);
		}
		getParams();
		for(ThreadTest thread: threads){
			System.out.println("Starting: " + thread.getNm());
			thread.run(amountOfBonks, amountOfZaps,size,cycles);
			thread.start();
		}
		
		boolean check;
		do{
			check = true;
			for(ThreadTest thread: threads){
				if(thread.isAlive()){
					check = false;
					System.out.println("waiting...");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}while(!check);
		
		for(ThreadTest thread: threads){
			thread.results();
			thread.interrupt();
		}
	}
	
	/**
	 * returns input from the keyboard
	 * @return
	 */
	public String getInput(){
		return input.nextLine().toUpperCase();
	}
	
	/**
	 * Prints out the menu options
	 */
	public void printMenu(){
		System.out.print("Welcome to bonks and zaps \n"
				+ "1 - run base simulation (20 bonks, 5 zaps, 20 cycles, 20*20 world) \n"
				+ "2 - custom simulation (X bonks, X zaps, X cycles, X*X world, player choice of zap control)\n"
				+ "3 - you control the zaps (Base simulation + player controlled zap movement) \n"
				+ "4 - multi-threading of multiple custom sims for comparison \n"
				+ "5 - quit \n"
				+ "input: ");
	}
}
