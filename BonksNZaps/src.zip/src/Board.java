import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Board {
	//use a 3 d array for x, y and all monsters in the room
	protected Cell world[][];
	int numOfBonks = 0;
	int worldSize= 20;
	Random rand = new Random();
	protected Display output;
	
	/**
	 * instanitates the board by creating the game world
	 * genbonks amount of bonks and genzap amount of zaps
	 * then lets the simulation run for cycle days
	 * @param genBonks
	 * @param genZaps
	 * @param cycles
	 * @throws CannotActException
	 */
	public Board(int genBonks, int genZaps, int size, boolean player) throws CannotActException{
		Position tempLoc = null;
		worldSize = size;
		world = new Cell[worldSize][worldSize];
		output = new Display(size);
		for(int x = 0; x < size; x++){
			for(int y = 0; y < size; y++){
				world[x][y] = new Cell();
			} 
		}
		//generates and places x bonks (default 20)
		for(int i = 1; i < (genBonks + 1); i++){
			numOfBonks += 1;
			tempLoc = new Position(getRandom(size),getRandom(size));
			Bonk temp = new Bonk(numOfBonks,tempLoc, size, null, null);
			world[tempLoc.getX()][tempLoc.getY()].add(temp);
		}
		//generates and places x zaps (default 5)
		if(player){
			genAllPlayzaps(tempLoc, genZaps);
		}
		else{
			genAllZaps(tempLoc,genZaps);
		}
	}
	private void genAllPlayzaps(Position tempLoc, int genZaps){
		for(int i = 1; i < (genZaps + 1); i++){
			tempLoc = new Position(getRandom(worldSize),getRandom(worldSize));
			Zap temp = new PlayerZap(i,tempLoc, worldSize);
			world[tempLoc.getX()][tempLoc.getY()].add(temp);
		}
	}
	private void genAllZaps(Position tempLoc, int genZaps){
		for(int i = 1; i < (genZaps + 1); i++){
			tempLoc = new Position(getRandom(worldSize),getRandom(worldSize));
			Zap temp = new Zap(i,tempLoc, worldSize);
			world[tempLoc.getX()][tempLoc.getY()].add(temp);
		}
	}
	
	
	/**
	 * simulates x days where cycle == x
	 * @param cycles
	 * @throws CannotActException
	 * @throws InterruptedException 
	 */
	public void run(int cycles) throws CannotActException, InterruptedException{
		for(int i = 0;i < cycles; i++){
			System.out.println("Day " +(i+1)+ " of day " +cycles);
			setActStatus();
			output.displayGrid(world);
			for(int x = 0; x < worldSize; x++){
				for(int y = 0; y < worldSize; y++){
					ArrayList<Being> temp = world[x][y].getList(); //gets the arraylist of that cell
					ArrayList<Being> toDelete = new ArrayList<Being>(); //beings to delete
					ArrayList<Being> born = new ArrayList<Being>(); //born lol
					for(int b =0; b < temp.size(); b++){
						Being B = temp.get(b);
						temp.remove(B);
						
						if(B instanceof Bonk && ((Bonk) B).getAct()){
							if(temp.size() > 1){
									born.addAll(((Bonk) B).breed(temp, numOfBonks));
									temp.removeAll(born);
							}
							if(((Bonk) B).getAct()){
								B.act();
							}
						}
						else if(B instanceof Zap){
							temp = ((Zap) B).kill(temp);
							if(((Zap) B).getAct()){
								B.act();
							}
						}
						Position tempLoc = B.getLocation();
						if(tempLoc.getX() == x && tempLoc.getY() == y){ //checks the move is legal
							temp.add(B);
						}
						else{
							world[tempLoc.getX()][tempLoc.getY()].add(B);
							toDelete.add(B);
						}
					}
					for(Being B: toDelete){
						temp.remove(B);
					}
					numOfBonks += (born.size());
					temp.addAll(born);
					world[x][y].setList(temp);
				}
			}
			Thread.sleep(1000);
		}
	}
	protected void setActStatus(){
		for(int x = 0; x < worldSize; x++){
			for(int y = 0; y < worldSize; y++){
				ArrayList<Being> temp = world[x][y].getList();
				for(Being B:temp){
					if(B instanceof Bonk){
						((Bonk) B).setBreed(true);
						((Bonk) B).setAct(true);
					}
					if(B instanceof Zap || B instanceof PlayerZap){
						((Zap) B).setAct(true);
					}
				}
				world[x][y].setList(temp);
			}
		}
	}
	
	/**
	 * returns a random int of 0 - number - 1
	 * @param number
	 * @return
	 */
	public int getRandom(int number){
		return rand.nextInt(number);
	}

}
