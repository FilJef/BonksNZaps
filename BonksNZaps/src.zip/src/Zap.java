import java.util.ArrayList;
import java.util.Random;

public class Zap implements Being{
	String name;
	Random rand = new Random();
	Position location;
	int worldSize;
	boolean act = true;
	
	public Zap(int number, Position tempLoc, int size) {
		name = "Z" + Integer.toString(number);
		location = tempLoc;
		worldSize = size;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void act() throws CannotActException{
		move();
		act = false;
	}
	
	public boolean getAct(){
		return act;
	}
	
	public void setAct(boolean input){
		act = input;
	}
	
	/**
	 * Movement is handled the same for both bonks and zaps, i use a single rand (0-8) rather than 2
	 * (-1 to 1) as this is easier to allow players control later #flair
	 */
	@Override
	public void move() {
		//location = new Position(location.getY() + (rand.nextInt(3)-1), location.getX()+(rand.nextInt(3)-1));
		
		int move = rand.nextInt(9);
		int tempX, tempY;
		switch(move){
			case 0:
				break;
			case 1:
				tempX = location.getX()-1;
				tempY = location.getY()-1;
				location = new Position(tempX,tempY);
				break;
			case 2:
				tempX = location.getX();
				tempY = location.getY()-1;
				location = new Position(tempX,tempY);
				break;
			case 3:
				tempX = location.getX()+1;
				tempY = location.getY()-1;
				location = new Position(tempX,tempY);
				break;
			case 4:
				tempX = location.getX()-1;
				tempY = location.getY();
				location = new Position(tempX,tempY);
				break;
			case 5:
				tempX = location.getX()+1;
				tempY = location.getY();
				location = new Position(tempX,tempY);
				break;
			case 6:
				tempX = location.getX()-1;
				tempY = location.getY()+1;
				location = new Position(tempX,tempY);
				break;
			case 7:
				tempX = location.getX();
				tempY = location.getY()+1;
				location = new Position(tempX,tempY);
				break;
			case 8:
				tempX = location.getX()+1;
				tempY = location.getY()+1;
				location = new Position(tempX,tempY);
				break;
		}
		
		if(location.getY() > worldSize -1){
			location.setY(worldSize -1);
		}
		else if(location.getY() < 0){
			location.setY(0);
		}
		
		if(location.getX() > worldSize -1){
			location.setX(worldSize -1);
		}
		else if(location.getX() < 0){
			location.setX(0);
		}
	}
	public ArrayList<Being> kill(ArrayList<Being> cellMates){
		for(Being B: cellMates){
			if(B instanceof Bonk){
				((Bonk) B).kill();
			}
		}
		return cellMates;
	}
	
	public String toString(){
		String returnable = name;
		return returnable;
	}

	@Override
	public void setLocation(Position temp){
		location = temp;
	}

	@Override
	public Position getLocation() {
		return location;
	}
}
